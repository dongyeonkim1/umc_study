export default function NotFoundPage() {
    return <div>notfound</div>;
}